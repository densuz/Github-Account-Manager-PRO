"""
Git Account Manager Pro
A professional Git account management tool with modular architecture.

Author: Git Account Manager Team
Version: 2.0.0
"""

__version__ = "2.0.0"
__author__ = "Git Account Manager Team"
__description__ = "Professional Git account management tool"
