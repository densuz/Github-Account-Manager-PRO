# Git Account Manager Pro - Complete Package

## 🎉 Welcome to Git Account Manager Pro v2.1.0!

This complete package includes everything you need to run Git Account Manager Pro in any way you prefer.

## 🚀 Quick Start

**Double-click `Launch.bat`** and choose your preferred method:

1. **Portable Version** - Run without installation
2. **Full Installer** - Install to your system
3. **Exit** - Close the launcher

## 📦 What's Included

### Core Application
- `GitAccountManagerPro.exe` - Main application executable
- `README.md` - Complete documentation
- `RELEASE_NOTES.md` - Detailed release notes
- `VERSION.txt` - Version information
- `LICENSE.txt` - License agreement

### Installation Options
- `Launch.bat` - Easy launcher with options
- `installer.py` - Python-based installer with GUI
- `installer.nsi` - NSIS installer script (for advanced users)
- `portable_launcher.py` - Portable launcher with language detection

## 🌐 Language Support

- **🇺🇸 English** - Full English language support
- **🇮🇩 Bahasa Indonesia** - Complete Indonesian language support
- **Auto-detection** - Automatically detects your system language
- **Easy switching** - Change language anytime

## 🔧 Installation Methods

### Method 1: Portable (Recommended for beginners)
- **No installation required**
- **Run from any folder**
- **No system changes**
- **Easy to remove**
- **Perfect for USB drives**

### Method 2: Full Installation
- **System integration**
- **Desktop shortcuts**
- **Start Menu entry**
- **Proper uninstaller**
- **Windows integration**

### Method 3: Advanced (NSIS)
- **Professional installer**
- **Windows-standard installation**
- **Automatic uninstaller**
- **System integration**

## 📋 System Requirements

- **Windows 10/11** (64-bit recommended)
- **Git** (for account management features)
- **Python 3.7+** (for installer and launcher features)

## 🚀 Getting Started

### For First-Time Users
1. **Double-click `Launch.bat`**
2. **Choose "1" for Portable Version**
3. **Select your language**
4. **Click "Launch Portable"**
5. **Start managing your Git accounts!**

### For System Installation
1. **Double-click `Launch.bat`**
2. **Choose "2" for Full Installer**
3. **Follow the installation wizard**
4. **Choose installation type and options**
5. **Launch from desktop or Start Menu**

### For Advanced Users
1. **Install NSIS** from https://nsis.sourceforge.io/
2. **Compile `installer.nsi`** to create professional installer
3. **Run the generated setup.exe**

## 🆘 Troubleshooting

### Python Not Found
- Install Python 3.7+ from https://python.org
- Ensure Python is added to system PATH
- Or use direct launch: double-click `GitAccountManagerPro.exe`

### Application Won't Start
- Ensure you have Windows 10/11
- Check if Git is installed: `git --version`
- Try running as administrator

### Language Issues
- Use the launcher to select language
- Or manually edit language settings in data folder

## 📞 Support & Updates

- **GitHub Repository**: https://github.com/densuz/Github-Account-Manager-PRO
- **Version**: 2.1.0
- **Release Date**: September 6, 2025
- **License**: Open Source

## 🎯 Features

- ✅ **Multi-Git Account Management**
- ✅ **Easy Account Switching**
- ✅ **Secure Token Storage**
- ✅ **Multi-Language Support** (English & Bahasa Indonesia)
- ✅ **Theme Support** (Dark, Light, System)
- ✅ **Portable & Installer Options**
- ✅ **Modern, Clean Interface**

---

**Thank you for using Git Account Manager Pro!** 🚀

If you find this tool helpful, please consider starring the repository on GitHub!
