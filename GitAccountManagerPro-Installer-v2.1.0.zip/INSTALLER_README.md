# Git Account Manager Pro - Installer Package

## 🚀 Installation Options

### Option 1: Python Installer (Recommended)
1. **Double-click `Install.bat`** to start the installer
2. **Choose installation type**:
   - **Portable Installation** - No system changes, run from any folder
   - **Full Installation** - Install to Program Files with shortcuts
3. **Select installation location**
4. **Choose options** (desktop shortcut, start menu, etc.)
5. **Click Install** to begin installation

### Option 2: NSIS Installer (Advanced)
1. **Compile the NSIS installer** using `installer.nsi`
2. **Run the generated setup.exe**
3. **Follow the installation wizard**

## 📁 What's Included

- `GitAccountManagerPro.exe` - Main application
- `Install.bat` - Easy installer launcher
- `installer.py` - Python-based installer with GUI
- `installer.nsi` - NSIS installer script
- `portable_launcher.py` - Portable launcher (for portable mode)
- Documentation files

## 🌐 Language Support

- **🇺🇸 English** - Full English language support
- **🇮🇩 Bahasa Indonesia** - Complete Indonesian language support
- **Auto-detection** - Automatically detects your system language

## 🔧 Installation Types

### Portable Installation
- **No system changes** - No registry modifications
- **Run from any folder** - Copy to USB, cloud storage, etc.
- **Easy removal** - Just delete the folder
- **Portable data** - Settings stored locally

### Full Installation
- **System integration** - Install to Program Files
- **Desktop shortcut** - Easy access from desktop
- **Start Menu entry** - Access from Start Menu
- **Proper uninstaller** - Clean removal via Control Panel
- **Windows integration** - Better system integration

## 📋 System Requirements

- **Windows 10/11** (64-bit recommended)
- **Git** (for account management features)
- **Python 3.7+** (for Python installer)
- **NSIS** (optional, for compiling NSIS installer)

## 🛠️ Building NSIS Installer

If you want to create a professional Windows installer:

1. **Install NSIS** from https://nsis.sourceforge.io/
2. **Right-click on `installer.nsi`**
3. **Select "Compile NSIS Script"**
4. **Run the generated `GitAccountManagerPro-Setup.exe`**

## 🆘 Troubleshooting

### Python Installer Issues
- Ensure Python 3.7+ is installed
- Check if Python is in your system PATH
- Try running as administrator

### NSIS Installer Issues
- Install NSIS from the official website
- Ensure all required files are present
- Check NSIS documentation for advanced options

### Application Won't Start
- Ensure you have Windows 10/11
- Check if Git is installed and accessible
- Try running as administrator

## 📞 Support

For issues, feature requests, or questions:
- GitHub: https://github.com/densuz/Github-Account-Manager-PRO
- Check README.md for detailed documentation

---

**Thank you for using Git Account Manager Pro!** 🚀
