# Git Account Manager Pro - Portable Version

## 🚀 Quick Start

1. **Double-click `Launch.bat`** to start the portable launcher
2. **Choose your language** (English or Bahasa Indonesia)
3. **Select launch options** (portable data folder, console, etc.)
4. **Click "Launch Portable"** to run the application

## 📁 What's Included

- `GitAccountManagerPro.exe` - Main application
- `Launch.bat` - Easy launcher script
- `portable_launcher.py` - Advanced launcher with options
- `installer.py` - Full installer (if you want to install later)
- Documentation files

## 🌐 Language Support

- **🇺🇸 English** - Full English language support
- **🇮🇩 Bahasa Indonesia** - Complete Indonesian language support
- **Auto-detection** - Automatically detects your system language

## 🔧 Portable Features

- **No Installation Required** - Run from any folder
- **Portable Data** - Settings stored in local 'data' folder
- **Easy Removal** - Just delete the folder
- **Language Persistence** - Your language choice is remembered

## 🚀 Alternative Launch Methods

### Method 1: Direct Launch
- Double-click `GitAccountManagerPro.exe` to run directly

### Method 2: Launcher (Recommended)
- Double-click `Launch.bat` for options and language selection

### Method 3: Python Launcher
- Run `python portable_launcher.py` for advanced options

## 📋 System Requirements

- **Windows 10/11** (64-bit recommended)
- **Git** (for account management features)
- **Python 3.7+** (optional, for launcher features)

## 🆘 Troubleshooting

### Application Won't Start
- Ensure you have Windows 10/11
- Check if Git is installed and accessible
- Try running as administrator

### Launcher Issues
- Install Python 3.7+ for launcher features
- Or use direct launch method (double-click .exe)

### Language Not Changing
- Use the launcher to select language
- Or manually edit `data/language_config.json`

## 📞 Support

For issues, feature requests, or questions:
- GitHub: https://github.com/densuz/Github-Account-Manager-PRO
- Check README.md for detailed documentation

---

**Thank you for using Git Account Manager Pro!** 🚀
